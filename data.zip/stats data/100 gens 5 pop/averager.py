import os
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors

import glob

# Create an empty DataFrame to store the combined data
combined_df = pd.DataFrame()

# Loop through all the CSV files
for i, file in enumerate(glob.glob('run *.csv')):
    # Read in the CSV file as a DataFrame
    df = pd.read_csv(file, header=None, names=['x', 'y'])
    
    # Add a column to identify which file the data came from
    df['file'] = os.path.basename(file)  # use os.path.basename() to extract the filename
    
    # Append the data to the combined DataFrame
    combined_df = combined_df.append(df)

# Filter out data points that are not (0, 0)
mask = (combined_df['x'] != 0) | (combined_df['y'] != 0)
combined_df = combined_df[mask]

# Get the mean and max values of y for each x value
idx = combined_df.groupby('x')['y'].idxmax()
mean_df = combined_df.groupby('x').mean().reset_index()
max_df = combined_df.groupby('x').max().reset_index()

max_value = df['x'].max()
maxdf = pd.DataFrame(columns=['x', 'y', 'file'])
print(max_value)
for i in range(max_value-3):
    print(i)
    

    # Get the row with the largest y value for x=1
    max_row = combined_df[combined_df['x'] == 2+i].sort_values(by='y', ascending=False).iloc[0]

    # Append the row to the maxdf DataFrame
    maxdf = maxdf.append(max_row, ignore_index=True)
    

print(maxdf)
files = ['run {}.csv'.format(i) for i in range(1, 26)]

# Use the mcolors library to get a list of 25 equally spaced RGB colors
colors = list(mcolors.CSS4_COLORS.values())[::len(mcolors.CSS4_COLORS)//25]

# Create a dictionary where each file name is mapped to a corresponding color
file_color_dict = dict(zip(files, colors))

print(file_color_dict)
# Create a figure and axis object
fig, ax = plt.subplots()

# Create a point plot of the mean y values for each x value
ax.plot(mean_df['x'], mean_df['y'], marker='o', label='Average Best Fitness')

# Create a scatter plot of the max y values for each x value
for x, y, file in maxdf.values:
    color = file_color_dict.get(file, 'k')
    ax.plot(x, y, marker='s', color=color)


# Set the axis labels and title
ax.set_title('Average And Highest Achieved Fitness per Number of Parts Across All Runs \n(5 Bots/Generation, 100 Generations, 25 Sets)')
ax.set_xlabel('Number of Parts in a Bot')
ax.set_ylabel('Fitness')
# Create a list of the unique files that are plotted in the scatter plot
unique_files = list(set(maxdf['file']))

# Create a custom legend with only the unique files and their corresponding colors
legend_handles = []
for file in unique_files:
    color = file_color_dict.get(file, 'k')
    handle = ax.scatter([], [], color=color, marker='s', label=file)
    legend_handles.append(handle)

# Add a legend
ax.legend()

# Show the plot
plt.show()
print(max_df)

combined_df.to_csv('combs.csv', index=False)
