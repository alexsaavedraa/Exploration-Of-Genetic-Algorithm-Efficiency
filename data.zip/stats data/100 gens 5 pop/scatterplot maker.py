import pandas as pd
import matplotlib.pyplot as plt
import glob

# Define a color map for the files
cmap = plt.get_cmap('tab20')

# Create an empty DataFrame to store the combined data
combined_df = pd.DataFrame()

# Loop through all the CSV files
for i, file in enumerate(glob.glob('*_2000_runs.csv')):
    # Read in the CSV file as a DataFrame
    df = pd.read_csv(file, header=None, names=['x', 'y'])
    
    # Add a column to identify which file the data came from
    df['file'] = file
    
    # Append the data to the combined DataFrame
    combined_df = combined_df.append(df)

# Filter out data points that are not (0, 0)
mask = (combined_df['x'] != 0) | (combined_df['y'] != 0)
combined_df = combined_df[mask]

# Create a figure and axis object
fig, ax = plt.subplots()

# Loop through the unique files in the data
for i, file in enumerate(combined_df['file'].unique()):
    # Filter the data for this file
    file_df = combined_df[combined_df['file'] == file]
    
    # Get the color and label for this file
    color = cmap(i)
    label = f"Run # {i}"
    
    # Create a scatterplot for this file
    ax.scatter(file_df['x'], file_df['y'], color=color, alpha=0.5, label=label)

# Set the axis labels
ax.set_title('Best performing bot for each number of Body Parts \n(5 Bots/Generation, 100 Generations, 25 Sets)')
ax.set_xlabel('Number of Body Parts')
ax.set_ylabel('Fitness')

# Add a legend
ax.legend()

# Show the plot
plt.show()
