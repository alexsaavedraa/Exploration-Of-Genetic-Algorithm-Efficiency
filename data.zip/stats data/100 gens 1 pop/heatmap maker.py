import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import glob

# Create an empty DataFrame to store the combined data
combined_df = pd.DataFrame()

# Loop through all the CSV files
for file in glob.glob('*_2000_runs.csv'):
    # Read in the CSV file as a DataFrame
    df = pd.read_csv(file, header=None, names=['x', 'y'])
    
    # Add a column to identify which file the data came from
    df['file'] = file
    
    # Append the data to the combined DataFrame
    combined_df = combined_df.append(df)

# Filter out data points that are not (0, 0)
mask = (combined_df['x'] != 0) | (combined_df['y'] != 0)
combined_df = combined_df[mask]

# Create a figure and axis object
fig, ax = plt.subplots()

# Calculate the bin edges for the X and Y data
x_edges = np.arange(combined_df['x'].min(), combined_df['x'].max()+1, 1)
y_edges = np.arange(combined_df['y'].min(), combined_df['y'].max()+1, 1)

# Create a histogram from the combined data
H, xedges, yedges = np.histogram2d(combined_df['x'], combined_df['y'], bins=(25, 25))

# Create a colormap
cmap = plt.cm.get_cmap('hot')

# Plot the histogram
pcm = ax.pcolormesh(xedges, yedges, H.T, cmap=cmap)
plt.colorbar(pcm)

# Set the axis labels
ax.set_xlabel('X')
ax.set_ylabel('Y')

# Show the plot
plt.show()
