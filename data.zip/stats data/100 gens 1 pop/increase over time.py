import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import glob

# Use glob to find all files that match the pattern '*_alldata.csv'
file_list = glob.glob('*_alldata.csv')
av_max = 0
# Loop through each file in the file list
for q, file in enumerate(file_list):
    # Read in the csv file using pandas
    data = pd.read_csv(file)

    # Initialize variables to store the maximum value and row number
    max_val = None
    max_row = None
    new_data = np.empty((0, 2))  # Initialize as 2D NumPy array
    if q == 0:
    # Loop through each row in the DataFrame
        for i, row in data.iterrows():
            # Get the maximum value and its row number for this row
            cur_max_val = row[1]
            cur_max_row = i

            # Update the maximum value and row number if a higher value is found
            if max_val is None or cur_max_val > max_val:
                max_val = cur_max_val
                max_row = cur_max_row

            # Append a new row to the new_data array
            new_data = np.vstack((new_data, [i, max_val]))
            if i >10:
                avmax = max_val
                break
    else:
        pass# Loop through each row in the DataFrame
        for i, row in data.iterrows():
            # Get the maximum value and its row number for this row
            cur_max_val = row[1]
            cur_max_row = i

            # Update the maximum value and row number if a higher value is found
            if max_val is None or cur_max_val > max_val:
                max_val = cur_max_val
                max_row = cur_max_row

            # Append a new row to the new_data array
            new_data = np.vstack((new_data, [i, max_val]))
            if i == 10:
                if max_val >= avmax:
                    avmax = (max_val+((i-1)*avmax))/i
                else:
                    break
    
# Create a line plot with the overall maximum value and its row number
    plt.plot(new_data[:,0], new_data[:,1], label=f"Run{file[:-11]}")

# Add a legend and axis labels to the plot
plt.xlabel('Generation')
plt.ylabel('Fitness (Distance Traveleld)')
plt.title('Best Fitness Achieved Versus Generation with agressive Pruning\n(1 Bots/Generation, 100 Generations, 100 Sets)')
plt.legend()
plt.show()
