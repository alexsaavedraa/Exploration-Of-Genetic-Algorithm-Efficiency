import pandas as pd

# Loop through the csv files
for i in range(100):
    try:
        # Open the csv file and add column names
        df = pd.read_csv(f"{i}_alldata.csv", names=["x", "y"])
        
        # Group the data by the integer in the x column
        grouped = df.groupby('x')
        
        # Find the maximum y value for each group
        max_y = grouped['y'].agg('max')
        
        # Create a new dataframe with the results
        result_df = pd.DataFrame({'x': max_y.index, 'y': max_y.values})
        
        # Save the new dataframe as a csv file
        result_df.to_csv(f"{i}_2000_runs.csv", header=False, index=False)
        result_df.to_csv(f"run {i}.csv", header=False, index=False)
    except:
        pass

